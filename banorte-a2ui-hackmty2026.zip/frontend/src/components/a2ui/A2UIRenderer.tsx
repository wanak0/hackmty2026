import React, { useState } from 'react';
import { A2UIScreen } from '../../types/a2ui';
import { HeaderBadge } from './HeaderBadge';
import { MetricComparison } from './MetricComparison';
import { PlanOptionList } from './PlanOptionList';
import { ActionButton } from './ActionButton';
import { ConfirmationCard } from './ConfirmationCard';
import { QuickSuggestions } from './QuickSuggestions';
import { InvestmentSimulator } from './InvestmentSimulator';
import { TransactionTable } from './TransactionTable';
import { TransferCard } from './TransferCard';
import { FinancialHealthScore } from './FinancialHealthScore';
import { AlertBanner } from './AlertBanner';
import { Sparkles, ChevronRight } from 'lucide-react';

interface A2UIRendererProps {
  screen: A2UIScreen;
  onAction: (actionType: string, payload?: any) => void;
  loading?: boolean;
}

export const A2UIRenderer: React.FC<A2UIRendererProps> = ({
  screen,
  onAction,
  loading = false
}) => {
  const [selectedPlanId, setSelectedPlanId] = useState<string>('plan_18m');
  const [liveTransferData, setLiveTransferData] = useState<any>(null);

  return (
    <div className="bg-white border border-gray-200 rounded-3xl p-5 sm:p-7 shadow-sm transition-all duration-300">
      {/* Mensaje de texto contextual del Asistente Maya */}
      {screen.assistantMessage && (
        <div className="mb-6 p-4 sm:p-5 rounded-2xl bg-[#FFF8F9] border-l-4 border-[#EB0029] border-y border-r border-[#FECDD3] text-sm text-gray-800 leading-relaxed shadow-xs flex items-start gap-3.5">
          <div className="w-8 h-8 rounded-xl bg-[#FFF0F2] border border-[#FECDD3] flex items-center justify-center text-[#EB0029] shrink-0 mt-0.5">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[11px] font-extrabold text-[#EB0029] uppercase tracking-wider block mb-0.5">
              Maya Banorte
            </span>
            <p className="text-gray-800 text-sm leading-relaxed font-medium">{screen.assistantMessage}</p>
          </div>
        </div>
      )}

      {/* Renderizado dinámico de componentes por tipo (Protocolo A2UI) */}
      <div className="space-y-4">
        {screen.components.map((comp) => {
          switch (comp.type) {
            case 'HeaderBadge':
              return (
                <HeaderBadge
                  key={comp.id}
                  tag={comp.props.tag}
                  title={comp.props.title}
                />
              );

            case 'AlertBanner':
              return (
                <AlertBanner
                  key={comp.id}
                  variant={comp.props.variant}
                  message={comp.props.message}
                />
              );

            case 'MetricComparison':
              return (
                <MetricComparison
                  key={comp.id}
                  balance={comp.props.balance}
                  currentCat={comp.props.currentCat}
                  preferentialCat={comp.props.preferentialCat}
                  estimatedSavings={comp.props.estimatedSavings}
                />
              );

            case 'PlanOptionList':
              return (
                <PlanOptionList
                  key={comp.id}
                  options={comp.props.options || []}
                  selectedPlanId={selectedPlanId}
                  onSelectPlan={(id) => setSelectedPlanId(id)}
                />
              );

            case 'InvestmentSimulator':
              return (
                <InvestmentSimulator
                  key={comp.id}
                  amount={comp.props.amount}
                  initialDays={comp.props.initialDays}
                  options={comp.props.options || []}
                />
              );

            case 'TransactionTable':
              return (
                <TransactionTable
                  key={comp.id}
                  transactions={comp.props.transactions || []}
                  totalExpenses={comp.props.totalExpenses || 0}
                  topCategory={comp.props.topCategory || 'Varios'}
                />
              );

            case 'TransferCard':
              return (
                <TransferCard
                  key={comp.id}
                  recipient={comp.props.recipient}
                  amount={comp.props.amount}
                  concept={comp.props.concept}
                  sourceAccount={comp.props.sourceAccount}
                  isNewContact={comp.props.isNewContact}
                  clabe={comp.props.clabe}
                  onChangeData={(data) => setLiveTransferData(data)}
                />
              );

            case 'FinancialHealthScore':
              return (
                <FinancialHealthScore
                  key={comp.id}
                  score={comp.props.score}
                  scoreRange={comp.props.scoreRange}
                  dti={comp.props.dti}
                  recommendations={comp.props.recommendations || []}
                />
              );

            case 'ActionButton':
              return (
                <ActionButton
                  key={comp.id}
                  label={comp.props.label}
                  actionType={comp.props.actionType}
                  variant={comp.props.variant}
                  loading={loading}
                  onClick={() =>
                    onAction(comp.props.actionType, {
                      planId: selectedPlanId,
                      ...comp.props,
                      ...(comp.props.actionType === 'CONFIRM_TRANSFER' && liveTransferData ? liveTransferData : {})
                    })
                  }
                />
              );

            case 'ConfirmationCard':
              return (
                <ConfirmationCard
                  key={comp.id}
                  operationId={comp.props.operationId}
                  cardName={comp.props.cardName}
                  last4={comp.props.last4}
                  months={comp.props.months}
                  monthlyQuota={comp.props.monthlyQuota}
                  appliedAt={comp.props.appliedAt}
                  nextPaymentDate={comp.props.nextPaymentDate}
                />
              );

            case 'QuickSuggestions':
              return (
                <QuickSuggestions
                  key={comp.id}
                  suggestions={comp.props.suggestions || []}
                  onSelectSuggestion={(text) => onAction('USER_PROMPT', { text })}
                />
              );

            case 'ActionList':
              return (
                <div key={comp.id} className="space-y-2.5 mb-4">
                  {comp.props.title && (
                    <span className="text-xs font-bold text-gray-600 uppercase tracking-wider block mb-2">
                      {comp.props.title}
                    </span>
                  )}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {(comp.props.actions || []).map((act: any, idx: number) => (
                      <button
                        key={idx}
                        onClick={() => onAction(act.actionType || 'USER_PROMPT', { text: act.label })}
                        className="p-4 rounded-2xl bg-white hover:bg-gray-50 border border-gray-200 hover:border-[#EB0029] text-xs font-bold text-gray-800 hover:text-gray-900 transition-all flex items-center justify-between text-left group shadow-xs"
                      >
                        <span>{act.label}</span>
                        <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-[#EB0029] group-hover:translate-x-0.5 transition-all" />
                      </button>
                    ))}
                  </div>
                </div>
              );

            default:
              return (
                <div key={comp.id} className="p-4 bg-gray-50 border border-gray-200 text-xs text-gray-600 rounded-2xl">
                  Componente A2UI: {comp.type}
                </div>
              );
          }
        })}
      </div>
    </div>
  );
};


