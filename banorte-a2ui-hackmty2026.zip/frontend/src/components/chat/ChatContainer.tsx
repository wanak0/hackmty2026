import React, { useState, useEffect } from 'react';
import {
  Send,
  RotateCcw,
  ArrowLeft,
  CreditCard,
  Shield,
  Sparkles,
  Wallet,
  ArrowUpRight,
  TrendingUp,
  PieChart,
  Smartphone,
  Monitor
} from 'lucide-react';
import { A2UIScreen } from '../../types/a2ui';
import { A2UIRenderer } from '../a2ui/A2UIRenderer';
import { BanorteLogo } from '../common/BanorteLogo';

interface ChatContainerProps {
  onBackToLanding: () => void;
}

export const ChatContainer: React.FC<ChatContainerProps> = ({ onBackToLanding }) => {
  const [inputMessage, setInputMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [screen, setScreen] = useState<A2UIScreen | null>(null);
  const [clientStatus, setClientStatus] = useState<any>(null);
  const [isPhoneView, setIsPhoneView] = useState(false);

  // Cliente resiliente: intenta primero por proxy de Vite y hace fallback directo a 127.0.0.1:3001
  const apiFetch = async (url: string, options?: RequestInit): Promise<Response> => {
    try {
      const res = await fetch(url, options);
      if (res.ok) return res;
      return await fetch(`http://127.0.0.1:3001${url}`, options);
    } catch (err) {
      return await fetch(`http://127.0.0.1:3001${url}`, options);
    }
  };

  // Cargar estado inicial del cliente
  const fetchStatus = async () => {
    try {
      const res = await apiFetch('/api/user/usr_carlos_01/status');
      if (res.ok) {
        const data = await res.json();
        setClientStatus(data);
      }
    } catch (e) {
      console.error('Error cargando estado del cliente', e);
    }
  };

  // Iniciar sesión con pantalla de bienvenida o mensaje inicial
  const initAgent = async (initialPrompt?: string) => {
    setLoading(true);
    try {
      const res = await apiFetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: initialPrompt || 'Hola',
          context: { userId: 'usr_carlos_01' }
        })
      });
      const data = await res.json();
      setScreen(data);
    } catch (error) {
      console.error('Error al comunicarse con el backend A2UI:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStatus();
    initAgent('Quiero pagar menos intereses de mi tarjeta');
  }, []);

  // Enviar mensaje del usuario
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || loading) return;

    const msg = inputMessage;
    setInputMessage('');
    setLoading(true);

    try {
      const res = await apiFetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: msg,
          context: { userId: 'usr_carlos_01' }
        })
      });
      const data = await res.json();
      setScreen(data);
      fetchStatus();
    } catch (error) {
      console.error('Error procesando mensaje:', error);
    } finally {
      setLoading(false);
    }
  };

  // Manejar acción viva disparada desde los componentes A2UI (cerrando el ciclo)
  const handleA2UIAction = async (actionType: string, payload?: any) => {
    if (actionType === 'USER_PROMPT') {
      setInputMessage(payload.text);
      setLoading(true);
      try {
        const res = await apiFetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: payload.text,
            context: { userId: 'usr_carlos_01' }
          })
        });
        const data = await res.json();
        setScreen(data);
      } finally {
        setLoading(false);
      }
      return;
    }

    if (actionType === 'VIEW_ACCOUNT' || actionType === 'VIEW_BALANCES') {
      initAgent('Quiero ver mis saldos');
      fetchStatus();
      return;
    }

    if (actionType === 'SHOW_DEBT_RESTRUCTURE_OPTIONS' || actionType === 'PAY_CARD') {
      initAgent('Quiero pagar menos intereses de mi tarjeta');
      fetchStatus();
      return;
    }

    if (actionType === 'SHOW_INVESTMENT') {
      initAgent('Quiero simular una inversión en pagaré');
      return;
    }

    if (actionType === 'VIEW_TRANSACTIONS') {
      initAgent('¿En qué he gastado este mes?');
      return;
    }

    // Acción viva de aplicar reestructuración, inversión o transferencia
    setLoading(true);
    try {
      const res = await apiFetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: 'Acción ejecutada desde componente vivo A2UI',
          context: {
            action: actionType,
            ...payload,
            userId: 'usr_carlos_01'
          }
        })
      });
      const data = await res.json();
      setScreen(data);
      fetchStatus();
    } catch (error) {
      console.error('Error aplicando acción A2UI:', error);
    } finally {
      setLoading(false);
    }
  };

  // Reiniciar la base de datos para la demo
  const handleReset = async () => {
    try {
      await apiFetch('/api/reset', { method: 'POST' });
      fetchStatus();
      initAgent('Quiero pagar menos intereses de mi tarjeta');
    } catch (e) {
      console.error('Error reseteando demo:', e);
    }
  };

  return (
    <div className="min-h-screen bg-[#F2F4F8] text-[#1E242D] flex flex-col selection:bg-[#EB0029] selection:text-white">
      {/* Topbar Oficial Banorte (Rojo Oficial / Blanco) */}
      <header className="bg-[#EB0029] text-white shadow-md sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <button
              onClick={onBackToLanding}
              className="px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white transition-colors flex items-center gap-1.5 text-xs font-bold"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Landing</span>
            </button>

            <div className="flex items-center gap-3">
              <BanorteLogo size="sm" variant="white" />
              <span className="text-white/40 text-xs hidden sm:inline">|</span>
              <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/20 text-[11px] font-bold text-white">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>Token Activo</span>
              </div>
            </div>
          </div>

          {/* Info del Cliente & Sesión */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-white/15 border border-white/20 px-3 py-1.5 rounded-xl text-xs">
              <div className="w-6 h-6 rounded-full bg-white text-[#EB0029] font-black text-xs flex items-center justify-center">
                C
              </div>
              <div className="hidden sm:block text-left text-white">
                <div className="font-bold leading-tight">Carlos Mendoza</div>
              </div>
            </div>

            {/* Toggle de Vista Teléfono / Escritorio */}
            <button
              onClick={() => setIsPhoneView(!isPhoneView)}
              className="px-2.5 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
              title={isPhoneView ? 'Ver vista completa' : 'Ver en marco de app móvil'}
            >
              {isPhoneView ? <Monitor className="w-3.5 h-3.5" /> : <Smartphone className="w-3.5 h-3.5" />}
              <span className="hidden md:inline">{isPhoneView ? 'Vista Amplia' : 'Vista Móvil'}</span>
            </button>

            <button
              onClick={handleReset}
              title="Reiniciar datos de demo a valores iniciales"
              className="px-2.5 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Reiniciar</span>
            </button>
          </div>
        </div>
      </header>

      <div className={`flex-1 flex flex-col ${isPhoneView ? 'py-6 px-4 items-center' : ''}`}>
        <div className={`w-full flex-1 flex flex-col ${isPhoneView ? 'max-w-md bg-white rounded-[40px] shadow-2xl border-[10px] border-gray-900 overflow-hidden relative' : ''}`}>
          
          {/* Header decorativo del teléfono si está en vista móvil */}
          {isPhoneView && (
            <div className="bg-[#EB0029] pt-3 pb-4 px-6 text-white text-center relative">
              <div className="w-24 h-4 bg-gray-900 rounded-full mx-auto mb-2" />
              <div className="text-sm font-black tracking-wider">BANORTE MÓVIL</div>
            </div>
          )}

          {/* Resumen Superior de Cuentas Banorte en Modo Claro */}
          <section className="bg-white border-b border-gray-200 py-4 px-4 sm:px-6">
            <div className="max-w-6xl mx-auto">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h1 className="text-lg sm:text-xl font-black text-gray-900 tracking-tight">
                      ¡Hola, Carlos! 👋
                    </h1>
                    <span className="text-[10px] bg-[#FFF0F2] text-[#EB0029] border border-[#FECDD3] px-2 py-0.5 rounded-full font-bold uppercase">
                      Banca Móvil Banorte
                    </span>
                  </div>
                </div>

                {/* Accesos Rápidos */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                  <button
                    onClick={() => initAgent('Quiero pagar menos intereses de mi tarjeta')}
                    className="px-2.5 py-1 rounded-lg bg-gray-100 hover:bg-red-50 hover:text-[#EB0029] text-xs font-bold text-gray-700 flex items-center gap-1 shrink-0 transition-colors border border-gray-200"
                  >
                    <CreditCard className="w-3.5 h-3.5 text-[#EB0029]" />
                    <span>Pagos Fijos</span>
                  </button>
                  <button
                    onClick={() => initAgent('Transferir $500 a mi mamá')}
                    className="px-2.5 py-1 rounded-lg bg-gray-100 hover:bg-emerald-50 hover:text-emerald-700 text-xs font-bold text-gray-700 flex items-center gap-1 shrink-0 transition-colors border border-gray-200"
                  >
                    <ArrowUpRight className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Transferir</span>
                  </button>
                  <button
                    onClick={() => initAgent('Quiero simular una inversión de $50,000')}
                    className="px-2.5 py-1 rounded-lg bg-gray-100 hover:bg-amber-50 hover:text-amber-700 text-xs font-bold text-gray-700 flex items-center gap-1 shrink-0 transition-colors border border-gray-200"
                  >
                    <TrendingUp className="w-3.5 h-3.5 text-amber-600" />
                    <span>Pagaré</span>
                  </button>
                  <button
                    onClick={() => initAgent('¿En qué he gastado este mes?')}
                    className="px-2.5 py-1 rounded-lg bg-gray-100 hover:bg-blue-50 hover:text-blue-700 text-xs font-bold text-gray-700 flex items-center gap-1 shrink-0 transition-colors border border-gray-200"
                  >
                    <PieChart className="w-3.5 h-3.5 text-blue-600" />
                    <span>Gastos</span>
                  </button>
                </div>
              </div>

              {/* Cards de Cuentas */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {/* Tarjeta de Crédito */}
                <div className="p-4 rounded-2xl bg-gradient-to-br from-[#FFFBF0] via-white to-white border border-amber-300 shadow-xs">
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
                        <CreditCard className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-[10px] uppercase font-bold text-amber-800 tracking-wider block">
                          Tarjeta de Crédito
                        </span>
                        <span className="text-xs font-black text-gray-900">Banorte Por Ti Oro (•••• 4821)</span>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-red-100 text-[#EB0029]">
                      REVOLVENTE
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-gray-100">
                    <div>
                      <span className="text-[10px] text-gray-500 uppercase font-semibold block">Deuda Actual</span>
                      <div className="text-lg font-black text-[#EB0029]">
                        ${clientStatus?.totalDebt?.toLocaleString('es-MX') || '18,400'} <span className="text-xs font-normal text-gray-500">MXN</span>
                      </div>
                    </div>
                    <div>
                      <span className="text-[10px] text-gray-500 uppercase font-semibold block">Límite de Crédito</span>
                      <div className="text-lg font-bold text-gray-800">
                        $35,000 <span className="text-xs font-normal text-gray-500">MXN</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Cuenta Débito */}
                <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-50/50 via-white to-white border border-emerald-300 shadow-xs">
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                        <Wallet className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-[10px] uppercase font-bold text-emerald-800 tracking-wider block">
                          Cuenta de Débito
                        </span>
                        <span className="text-xs font-black text-gray-900">Cuenta Enlace Digital (•••• 4092)</span>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                      ACTIVA
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-gray-100">
                    <div>
                      <span className="text-[10px] text-gray-500 uppercase font-semibold block">Saldo Disponible</span>
                      <div className="text-lg font-black text-emerald-700">
                        ${clientStatus?.checkingBalance?.toLocaleString('es-MX') || '13,650'} <span className="text-xs font-normal text-gray-500">MXN</span>
                      </div>
                    </div>
                    <div>
                      <span className="text-[10px] text-gray-500 uppercase font-semibold block">CLABE</span>
                      <div className="text-xs font-mono font-bold text-gray-700 mt-1">
                        072580012345678901
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Área Principal de Trabajo A2UI: Maya Live Agent */}
          <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-6 flex flex-col justify-between">
            {/* Renderizado de Pantalla Dinámica A2UI */}
            <div className="flex-1 flex flex-col justify-center">
              {loading && !screen ? (
                <div className="text-center py-16">
                  <div className="inline-flex p-4 rounded-3xl bg-[#FFF0F2] border border-[#FECDD3] text-[#EB0029] animate-pulse mb-3 shadow-sm">
                    <Sparkles className="w-8 h-8 animate-spin" />
                  </div>
                  <h3 className="text-base font-black text-gray-900 mb-1">Maya Banorte está construyendo tu pantalla...</h3>
                  <p className="text-xs font-medium text-gray-500">Protocolo A2UI en tiempo real</p>
                </div>
              ) : screen ? (
                <A2UIRenderer
                  screen={screen}
                  onAction={handleA2UIAction}
                  loading={loading}
                />
              ) : null}
            </div>

            {/* Input Bar para el usuario en modo claro */}
            <div className="mt-6 pt-3 border-t border-gray-200 sticky bottom-2 bg-white/95 backdrop-blur-md rounded-2xl p-2 shadow-xs">
              {/* Chips de Intención Rápida */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-2 text-xs">
                <span className="text-[10px] text-gray-500 shrink-0 font-bold uppercase">Maya:</span>
                {[
                  { label: '💳 Reestructurar Deuda', prompt: 'Quiero pagar menos intereses de mi tarjeta' },
                  { label: '📈 Pagaré $50k', prompt: 'Quiero simular una inversión de $50,000' },
                  { label: '📊 Mis Gastos', prompt: '¿En qué he gastado este mes?' },
                  { label: '⚡ Enviar $500 a Mamá', prompt: 'Transferir $500 a mi mamá' },
                  { label: '🩺 Score Buró', prompt: '¿Cómo está mi salud financiera y score?' }
                ].map((chip, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setInputMessage(chip.prompt);
                      initAgent(chip.prompt);
                    }}
                    className="shrink-0 px-3 py-1 rounded-full bg-gray-100 hover:bg-[#FFF0F2] hover:text-[#EB0029] border border-gray-200 hover:border-[#FECDD3] text-[11px] text-gray-700 transition-all font-semibold"
                  >
                    <span>{chip.label}</span>
                  </button>
                ))}
              </div>

              <form onSubmit={handleSubmit} className="relative flex items-center">
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Habla con Maya Banorte (ej: 'Quiero pagar menos intereses de mi tarjeta')..."
                  className="w-full bg-[#F4F5F7] border border-gray-300 focus:border-[#EB0029] focus:bg-white focus:ring-2 focus:ring-[#EB0029]/20 rounded-xl px-4 py-3.5 pr-14 text-sm text-gray-900 placeholder-gray-500 outline-none transition-all shadow-xs font-medium"
                />
                <button
                  type="submit"
                  disabled={loading || !inputMessage.trim()}
                  className="absolute right-2 p-2.5 rounded-lg bg-[#EB0029] hover:bg-[#D40024] text-white disabled:opacity-40 transition-all shadow-xs active:scale-95"
                >
                  <Send className="w-4 h-4 stroke-[2.5]" />
                </button>
              </form>

              <div className="flex items-center justify-between text-[10px] text-gray-500 mt-2 px-1 font-medium">
                <span className="flex items-center gap-1 text-gray-600">
                  <Shield className="w-3 h-3 text-[#EB0029]" />
                  <span>Conexión segura cifrada · Core Bancario Banorte (MCP)</span>
                </span>
                <span className="font-semibold text-gray-700">Banorte Móvil A2UI</span>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};
